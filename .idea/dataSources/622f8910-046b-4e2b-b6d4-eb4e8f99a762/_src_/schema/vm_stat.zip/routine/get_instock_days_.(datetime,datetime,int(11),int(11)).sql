CREATE FUNCTION get_instock_days_(from_date DATETIME, to_date DATETIME, the_store_id INT, the_good_id INT)
  RETURNS INT
  BEGIN
  DECLARE tid, fid, cid INT(11);
  DECLARE last_amnt, amnt FLOAT;
  DECLARE shifts INT DEFAULT 0;
  DECLARE last_amnt_date, amnt_date DATETIME;
  DECLARE done INT DEFAULT FALSE;
  DECLARE days INT;

  DECLARE cur1 CURSOR FOR SELECT `id`,`amount`,`updated` FROM storegoods sg WHERE `store_id`=the_store_id AND `id`>=fid AND `id`<=tid AND `good_id`=the_good_id;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  SET @debug_enabled = TRUE;
  call debug_msg(@debug_enabled, concat_ws(' ', "get_instock_days::", "from_date:", from_date, "to_date:", to_date, "the_store_id:", the_store_id, "the_good_id:", the_good_id));
  IF the_store_id <=0 THEN
      RETURN DATEDIFF(to_date,from_date)+1;
  END IF;
  SELECT ifnull(max(s.id),0) AS mu INTO fid FROM storegoods s WHERE store_id = the_store_id and s.good_id=the_good_id AND s.updated <=from_date;
  SELECT ifnull(max(s.id),0) AS mu INTO tid FROM storegoods s WHERE store_id = the_store_id and s.good_id=the_good_id AND s.updated <=to_date;
  
  if tid=0 THEN 
    RETURN 0;
  END IF;
  if fid = 0 THEN
    SELECT min(s.id) AS mu INTO fid FROM storegoods s WHERE store_id = the_store_id and s.good_id=the_good_id AND s.updated > from_date;
  END IF;

  IF fid=tid then
    SELECT amount INTO amnt from storegoods where id=fid;
    call debug_msg(@debug_enabled, concat_ws(' ',"tid:", tid, "fid:", fid,"amount:",amnt));
    IF amnt>0 THEN
      RETURN DATEDIFF(to_date,from_date);
    ELSE
      RETURN 0;
    END IF;
  ELSE
    call debug_msg(@debug_enabled, concat_ws(' ',"tid:", tid, "fid:", fid));
    OPEN cur1;
    FETCH cur1 INTO cid,last_amnt,last_amnt_date;
    SET last_amnt_date = from_date;
    call debug_msg(@debug_enabled, concat_ws(' ',"first_amnt:", last_amnt, "first_date:", last_amnt_date));
    IF last_amnt>0 THEN
      SET shifts = 1;
      call debug_msg(@debug_enabled, concat_ws(' ',"SHIFTS+: 1 at beging:", last_amnt_date));
    END IF;

    read_loop: LOOP

        FETCH cur1 INTO cid,amnt,amnt_date;
        IF done THEN
          LEAVE read_loop;
        END IF;


      IF amnt>0 or amnt<last_amnt THEN
        SET days=DATEDIFF(amnt_date,last_amnt_date);
        IF days > 0 then
          IF last_amnt>0 or last_amnt>amnt THEN
            SET shifts = shifts + days;
            call debug_msg(@debug_enabled, concat_ws(' ',"SHIFTS+days: amnt:", amnt, "amnt_date:", amnt_date, "last_amnt:", last_amnt, "last_amnt_date:", last_amnt_date,"DAYS:",days,"shifts:", shifts,"cid:",cid));
          ELSE
            SET shifts = shifts + 1;
            call debug_msg(@debug_enabled, concat_ws(' ',"SHIFTS+1: amnt:", amnt, "amnt_date:", amnt_date, "last_amnt:", last_amnt, "last_amnt_date:", last_amnt_date,"DAYS:",days,"shifts:", shifts,"cid:",cid));
          END IF;
        END IF;
        SET last_amnt_date=amnt_date;
      END IF;

      SET last_amnt=amnt;

  END LOOP;
  CLOSE cur1;
  END IF;
  call debug_msg(@debug_enabled, concat_ws(' ',"get_instock_days::->", shifts));

  IF shifts=0 THEN
    return 1; /*to avoid devide by zero exception if sales are zero or not*/
  END IF;
  RETURN shifts;
END;
