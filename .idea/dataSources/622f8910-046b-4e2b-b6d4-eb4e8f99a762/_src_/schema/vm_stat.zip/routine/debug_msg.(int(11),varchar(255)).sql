CREATE PROCEDURE debug_msg(IN enabled INT, IN msg VARCHAR(255))
  BEGIN
    IF enabled THEN BEGIN
      insert into sp_logs(log) values(msg);
    END; END IF;
  END;
