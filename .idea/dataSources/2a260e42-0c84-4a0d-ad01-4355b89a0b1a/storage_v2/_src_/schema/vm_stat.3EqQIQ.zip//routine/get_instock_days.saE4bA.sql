create
    definer = root@localhost function get_instock_days(from_date datetime, to_date datetime, the_store_id int,
                                                       the_good_id int) returns int
BEGIN
  DECLARE tid, fid, cid INT(11);
  DECLARE last_amnt, amnt FLOAT;
  DECLARE shifts INT DEFAULT 0;
  DECLARE last_amnt_date, amnt_date DATETIME;
  DECLARE done INT DEFAULT FALSE;
  DECLARE days INT;

  DECLARE cur1 CURSOR FOR SELECT `id`,`amount`,`updated` FROM storegoods WHERE `store_id`=the_store_id AND `id`>=fid AND `id`<=tid AND `good_id`=the_good_id;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  SET @debug_enabled = FALSE;

  SELECT max(s.id) AS mu INTO fid FROM storegoods s WHERE store_id = the_store_id and s.good_id=the_good_id AND s.updated <=from_date;
  SELECT max(s.id) AS mu INTO tid FROM storegoods s WHERE store_id = the_store_id and s.good_id=the_good_id AND s.updated <=to_date;

  IF fid=tid then
    SELECT amount INTO amnt from storegoods where id=fid;
    IF amnt>0 THEN
      RETURN DATEDIFF(from_date,to_date);
    ELSE
      RETURN 0;
    END IF;
  ELSE
    OPEN cur1;
    FETCH cur1 INTO cid,last_amnt,last_amnt_date;
    SET last_amnt_date = from_date;
    IF last_amnt>0 THEN
      SET shifts = 1;
    END IF;
  read_loop: LOOP
      FETCH cur1 INTO cid,amnt,amnt_date;
      IF done THEN
        LEAVE read_loop;
      END IF;
      IF amnt>0 THEN
        SET days=DATEDIFF(amnt_date,last_amnt_date);
        IF days > 0 then
          IF last_amnt>0 THEN
            SET shifts = shifts + days;
          ELSE
            SET shifts = shifts + 1;
          END IF;
        END IF;
        SET last_amnt_date=amnt_date;
      END IF;
      SET last_amnt=amnt;
    END LOOP;
    CLOSE cur1;
  END IF;
  RETURN shifts;
END;

